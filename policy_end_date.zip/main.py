import os
from pymongo import MongoClient
import sys
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging

# MongoDB connection URI
uri = os.getenv("STAGING_DB", "mongodb://hillcroftProdUser:MioMienoosaengei2ieh@172.26.0.43:38028/?authSource=admin")
db_name = os.getenv("DB_NAME", "hillcroft_insurance")


filter_query = {
    "product": "health",
    "paidamount": { "$gt": 0 },
    "policyStartDate": { "$exists": True },
    "$or": [
        { "policyEndDate": { "$exists": False } },
        { "policyEndDate": { "$eq": None } }
    ]
}

"""
Logging Configurations
"""
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging

def calculate_policy_end_date(policy_start_date_str, policy):
    """
    Calculate the end date of a policy given its start date and policy period.
    If periodName is missing, defaults to 12 months (yearly).
    """
    formats = ("%d/%m/%Y", "%Y/%d/%m", "%m/%d/%Y", "%Y-%d-%m", "%d-%m-%Y", "%m-%d-%Y", "%Y-%m-%d")
    
    # Parse start date from string
    for fmt in formats:
        try:
            start_date = datetime.strptime(policy_start_date_str, fmt)
            break
        except ValueError:
            continue
    else:
        logging.error(f"FAILED-> Policy start date '{policy_start_date_str}' does not match expected formats.")
        raise ValueError(f"Policy start date '{policy_start_date_str}' does not match expected formats.")

    # Determine duration in months based on period name
    period_name = (policy.get("periodName") or "").strip().lower()

    if "three" in period_name:
        months_to_add = 3
    elif "six" in period_name:
        months_to_add = 6
    else:
        # Default to 12 months (yearly)
        months_to_add = 12

    # Add months and subtract one day
    end_date = start_date + relativedelta(months=months_to_add) - timedelta(days=1)
    return end_date.strftime("%d/%m/%Y")



def update():
    # Connect to MongoDB using a context manager
    with MongoClient(uri) as client:
        logging.info("Connecting to MongoDB...")
        # Access the database and collection
        if not client:
            logging.error("❌ Failed to connect to MongoDB.")
            sys.exit(1)
        logging.info("✅ Connected to MongoDB successfully.")
        db = client[db_name]
        logging.info(f"Accessing database: {db_name}")
        if not db:
            logging.error(f"❌ Failed to connect to database: {db_name}")
            sys.exit(1)
        logging.info(f"✅ Connected to database: {db_name}")
        collection = db["cover_policy"]

        docs = collection.find(filter_query)
        updated_count = 0

        with open("updatepolicy.txt", "w") as f:
            for doc in docs:
                start_date = doc.get("policyStartDate")
                policy = doc.get("policy", {})
                period_name = policy.get("periodName", "N/A")
                logging.info(f"Policy with _id:{doc['_id']} has Period Name: {period_name} and Start Date: {start_date}")
                logging.info(f"Updating [policy: {doc['_id']}]")
                try:
                    end_date = calculate_policy_end_date(start_date, policy)
                    update_fields = {
                        "policyEndDate": end_date,
                    }

                    # Uncomment to perform actual update
                    # collection.update_one(
                    #     { "_id": doc["_id"] },
                    #     { "$set": update_fields }
                    # )

                    logging.info(f"✅ Updated [policy: {doc['_id']}], policyStartDate: {start_date} → policyEndDate: {end_date}")
                    f.write(str(doc['_id']) + "\n")
                    updated_count += 1
                except Exception as e:
                    logging.error(f"❌ Error processing document {doc['_id']}: {e}")

            logging.info(f"✅ Updated {updated_count} documents.")

if __name__ == "__main__":
    logging.info("Starting policy end date update process.")
    try:
        update()
        logging.info("Policy end date update process completed successfully.")
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        sys.exit(1)
